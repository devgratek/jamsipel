-- MySQL dump 10.15  Distrib 10.0.20-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u558025680_jm
-- ------------------------------------------------------
-- Server version	10.0.20-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cyb_baris`
--

DROP TABLE IF EXISTS `cyb_baris`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_baris` (
  `br_id` int(5) NOT NULL AUTO_INCREMENT,
  `br_nama` varchar(5) NOT NULL,
  `br_desc` varchar(54) DEFAULT NULL,
  PRIMARY KEY (`br_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_baris`
--

/*!40000 ALTER TABLE `cyb_baris` DISABLE KEYS */;
INSERT INTO `cyb_baris` VALUES (1,'NULL','Tidak ada keterangan baris'),(2,'B1',NULL),(3,'B2',NULL),(4,'B3',NULL),(5,'B4',NULL),(6,'B5',NULL),(7,'B6',NULL),(8,'B7',NULL),(9,'B8',NULL),(10,'B9',NULL),(11,'B10',NULL),(12,'B11',NULL),(13,'B12',NULL),(14,'B13',NULL),(15,'B14',NULL),(16,'B15',NULL),(17,'B16',NULL),(18,'B17',NULL),(19,'B18',NULL),(20,'B19',NULL),(21,'B20',NULL),(22,'B21',NULL),(23,'B22',NULL),(24,'B23',NULL),(25,'B24',NULL),(26,'B25',NULL),(27,'B26',NULL),(28,'B27',NULL),(29,'B28',NULL),(30,'B29',NULL),(31,'B30',NULL);
/*!40000 ALTER TABLE `cyb_baris` ENABLE KEYS */;

--
-- Table structure for table `cyb_golongan`
--

DROP TABLE IF EXISTS `cyb_golongan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_golongan` (
  `gol_id` int(3) NOT NULL AUTO_INCREMENT,
  `gol_nama` varchar(8) NOT NULL,
  `gol_desc` varchar(54) DEFAULT NULL,
  PRIMARY KEY (`gol_id`),
  UNIQUE KEY `gol_nama` (`gol_nama`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_golongan`
--

/*!40000 ALTER TABLE `cyb_golongan` DISABLE KEYS */;
INSERT INTO `cyb_golongan` VALUES (1,'NULL','Tidak ada keterangan golongan'),(2,'I',NULL),(3,'II',NULL),(4,'III',NULL),(5,'IV',NULL),(6,'V',NULL),(7,'VI',NULL),(8,'VIIa',NULL),(9,'VIIb',NULL),(10,'VIIc',NULL),(11,'VIId',NULL),(12,'VIIe',NULL);
/*!40000 ALTER TABLE `cyb_golongan` ENABLE KEYS */;

--
-- Table structure for table `cyb_jabatan`
--

DROP TABLE IF EXISTS `cyb_jabatan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_jabatan` (
  `jb_id` int(5) NOT NULL AUTO_INCREMENT,
  `jb_kode` varchar(8) NOT NULL,
  `jb_nama` varchar(64) NOT NULL,
  `jb_desc` varchar(64) DEFAULT '-',
  `jb_unit_kerja` int(11) NOT NULL,
  `jb_order` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`jb_id`),
  UNIQUE KEY `jb_kode` (`jb_kode`),
  KEY `jb_unit_kerja` (`jb_unit_kerja`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_jabatan`
--

/*!40000 ALTER TABLE `cyb_jabatan` DISABLE KEYS */;
INSERT INTO `cyb_jabatan` VALUES (1,'NULL','Not Set','Tidak Memiliki keterangan jabatan',1,0),(2,'GM','General Manager','Pimpinan Cabang',10,1),(4,'DGMTCM','Deputy General Manager Toll Collection Management','',21,1),(5,'EFM','Electric Facility Manager','',15,1),(6,'SEFC','SO Electric Facility Controlling','',15,2),(7,'SEFP','SO Electric Facility Preparation','',15,3),(8,'SEFE','SO Electric Facility Engineering','',15,4),(9,'EFCO','Electric Facility Controlling Officer','',15,5);
/*!40000 ALTER TABLE `cyb_jabatan` ENABLE KEYS */;

--
-- Table structure for table `cyb_levels`
--

DROP TABLE IF EXISTS `cyb_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_levels` (
  `lvl_id` int(11) NOT NULL AUTO_INCREMENT,
  `lvl_code` int(2) NOT NULL,
  `lvl_name` varchar(21) NOT NULL,
  PRIMARY KEY (`lvl_id`),
  UNIQUE KEY `lvl_code` (`lvl_code`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_levels`
--

/*!40000 ALTER TABLE `cyb_levels` DISABLE KEYS */;
INSERT INTO `cyb_levels` VALUES (1,1,'Super Administrator'),(2,2,'Administrator'),(3,4,'Pengelola'),(4,5,'Karyawan');
/*!40000 ALTER TABLE `cyb_levels` ENABLE KEYS */;

--
-- Table structure for table `cyb_logs`
--

DROP TABLE IF EXISTS `cyb_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_code` varchar(12) NOT NULL,
  `log_info` varchar(64) NOT NULL,
  `log_kategori` varchar(24) NOT NULL,
  `log_user` int(2) NOT NULL,
  `log_level` int(2) NOT NULL,
  `log_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `log_user` (`log_user`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_logs`
--

/*!40000 ALTER TABLE `cyb_logs` DISABLE KEYS */;
INSERT INTO `cyb_logs` VALUES (2,'DELETING','Karyawan dengan npp <b>45455</b>','Penghapus',2,3,'2016-02-05 08:21:01'),(3,'CREATE','Karyawan dengan nama <b>User Kiswanto</b> sudah disimpan.','Registrasi',2,3,'2016-02-05 08:22:18'),(4,'DELETING','Karyawan dengan npp <b>444</b> sudah dihapus','Penghapusan',2,3,'2016-02-05 08:22:41'),(5,'LOGOUT','Aktifitas logout <b>demo</b>.','Aktifitas',2,4,'2016-02-05 08:37:29'),(6,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-05 08:37:44'),(7,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-05 10:17:45'),(8,'LOGOUT','Aktifitas logout <b>demo</b> terakhir.','Aktifitas',2,4,'2016-02-05 11:16:24'),(9,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-05 12:37:19'),(10,'LOGOUT','Aktifitas logout <b>demo</b> terakhir.','Aktifitas',2,4,'2016-02-05 15:39:42'),(11,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-05 15:39:58'),(12,'LOGOUT','Aktifitas logout <b>demo</b> terakhir.','Aktifitas',2,4,'2016-02-05 15:41:00'),(13,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-05 15:41:15'),(14,'LOGOUT','Aktifitas logout <b>demo</b> terakhir.','Aktifitas',2,4,'2016-02-05 15:41:47'),(15,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-05 15:42:10'),(16,'UPDATED','Aktifitas perubahan password username <b>demo</b> .','Aktifitas',2,4,'2016-02-05 15:51:38'),(17,'UPDATED','Aktifitas perubahan password username <b>demo</b> .','Aktifitas',2,4,'2016-02-05 16:03:13'),(18,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-06 18:00:39'),(19,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-09 13:42:00'),(20,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-09 13:45:22'),(21,'UPDATED','perubahan data <b>user testing</b> sudah disimpan.','Perubahan',2,3,'2016-02-09 14:12:01'),(22,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-09 17:22:29'),(23,'LOGIN','Aktifitas login dengan username <b>11111</b> .','Aktifitas',25,4,'2016-02-09 17:27:32'),(24,'LOGIN','Aktifitas login dengan username <b>11111</b> .','Aktifitas',25,4,'2016-02-09 17:29:14'),(25,'LOGIN','Aktifitas login dengan username <b>11111</b> .','Aktifitas',25,4,'2016-02-09 17:31:15'),(26,'LOGIN','Aktifitas login dengan username <b>11111</b> .','Aktifitas',25,4,'2016-02-09 17:56:58'),(27,'LOGOUT','Aktifitas logout <b>11111</b> terakhir.','Aktifitas',25,4,'2016-02-09 17:58:54'),(28,'LOGIN','Aktifitas login dengan username <b>11111</b> .','Aktifitas',25,4,'2016-02-09 18:33:26'),(29,'LOGOUT','Aktifitas logout <b>11111</b> terakhir.','Aktifitas',25,4,'2016-02-09 18:36:09'),(30,'LOGIN','Aktifitas login dengan username <b>11111</b> .','Aktifitas',25,4,'2016-02-09 21:42:48'),(31,'LOGIN','Aktifitas login dengan username <b>11111</b> .','Aktifitas',25,4,'2016-02-09 22:52:51'),(32,'LOGIN','Aktifitas login dengan username <b>11111</b> .','Aktifitas',25,4,'2016-02-10 09:32:51'),(33,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-13 08:06:52'),(34,'LOGOUT','Aktifitas logout <b>demo</b> terakhir.','Aktifitas',2,4,'2016-02-13 08:10:56'),(35,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-16 14:31:26'),(36,'CREATE','Karyawan dengan nama <b>Lela nurlaela sari</b> sudah disimpan.','Registrasi',2,3,'2016-02-16 14:43:14'),(37,'UPDATED','perubahan data <b>Lela nurlaela sari</b> sudah disimpan.','Perubahan',2,3,'2016-02-16 14:53:00'),(38,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-17 06:49:31'),(39,'CREATE','Karyawan dengan nama <b>Teguh Hartono</b> sudah disimpan.','Registrasi',2,3,'2016-02-17 06:54:50'),(40,'LOGOUT','Aktifitas logout <b>demo</b> terakhir.','Aktifitas',2,4,'2016-02-17 06:55:00'),(41,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-17 06:55:36'),(42,'DELETING','Karyawan dengan npp <b>06536</b> sudah dihapus','Penghapusan',2,3,'2016-02-17 06:56:44'),(43,'CREATE','Karyawan dengan nama <b>Teguh Hartono</b> sudah disimpan.','Registrasi',2,3,'2016-02-17 06:57:47'),(44,'LOGOUT','Aktifitas logout <b>demo</b> terakhir.','Aktifitas',2,4,'2016-02-17 07:00:12'),(45,'LOGIN','Aktifitas login dengan username <b>11111</b> .','Aktifitas',25,4,'2016-02-17 10:37:31'),(46,'LOGOUT','Aktifitas logout <b>11111</b> terakhir.','Aktifitas',25,4,'2016-02-17 10:38:04'),(47,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-17 10:38:12'),(48,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-17 11:11:34'),(49,'LOGOUT','Aktifitas logout <b>demo</b> terakhir.','Aktifitas',2,4,'2016-02-17 11:17:32'),(50,'LOGIN','Aktifitas login dengan username <b>11111</b> .','Aktifitas',25,4,'2016-02-17 11:18:24'),(51,'LOGOUT','Aktifitas logout <b>11111</b> terakhir.','Aktifitas',25,4,'2016-02-17 11:18:36'),(52,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-17 11:18:55'),(53,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-17 11:19:04'),(54,'UPDATED','perubahan data <b>Yusep Supriatna</b> sudah disimpan.','Perubahan',2,3,'2016-02-17 11:21:50'),(55,'DELETED','Unit Kerja <b>CB</b> sudah dihapus.','Penghapusan',2,2,'2016-02-17 11:25:05'),(56,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-17 11:33:40'),(57,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-17 11:39:21'),(58,'LOGOUT','Aktifitas logout <b>demo</b> terakhir.','Aktifitas',2,4,'2016-02-17 11:41:11'),(59,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-17 13:44:06'),(60,'UPDATED','Aktifitas perubahan password username <b>qRZq9EEFXhoFbu2vkMn+nui','Aktifitas',26,4,'2016-02-17 13:44:58'),(61,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-17 17:49:19'),(62,'LOGIN','Aktifitas login dengan username <b>demo</b> .','Aktifitas',2,4,'2016-02-18 07:34:08'),(63,'DELETING','Karyawan dengan npp <b>11111</b> sudah dihapus','Penghapusan',2,3,'2016-02-18 07:34:27'),(64,'DELETING','Karyawan dengan npp <b>06536</b> sudah dihapus','Penghapusan',2,3,'2016-02-18 07:34:34'),(65,'CREATE','Karyawan dengan nama <b>Teguh Hartono</b> sudah disimpan.','Registrasi',2,3,'2016-02-18 07:35:35'),(66,'UPDATED','perubahan data <b>user testing</b> sudah disimpan.','Perubahan',2,3,'2016-02-18 07:48:00'),(67,'UPDATED','perubahan data <b>user testing</b> sudah disimpan.','Perubahan',2,3,'2016-02-18 07:49:52'),(68,'LOGIN','Aktifitas login dengan username <b>06536</b> .','Aktifitas',29,4,'2016-02-18 07:54:02');
/*!40000 ALTER TABLE `cyb_logs` ENABLE KEYS */;

--
-- Table structure for table `cyb_pelatihan`
--

DROP TABLE IF EXISTS `cyb_pelatihan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_pelatihan` (
  `pel_id` int(11) NOT NULL AUTO_INCREMENT,
  `pel_info` int(2) NOT NULL,
  `pel_kode` varchar(9) NOT NULL,
  `pel_nama` varchar(125) NOT NULL,
  `pel_jenis` int(3) NOT NULL,
  `pel_tempat` varchar(99) NOT NULL,
  `pel_penyelenggara` varchar(21) NOT NULL DEFAULT '-',
  `pel_keterangan` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`pel_id`),
  UNIQUE KEY `pel_kode` (`pel_kode`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_pelatihan`
--

/*!40000 ALTER TABLE `cyb_pelatihan` DISABLE KEYS */;
INSERT INTO `cyb_pelatihan` VALUES (1,0,'12/JMPL/P','Mengolah Informasi dengan Ms Excel',1,'Jakarta','1','test'),(2,0,'13/JMPL/P','Menghitung Pajak Air dan Listrik',2,'Jakarta','1',''),(3,0,'JM/788/16','Keselamatan Kerja',1,'Hotel Imperium Jakarta','PT nabila','-'),(4,0,'XX112D','Microsoft Excel',2,'Gedung Sor Biru','Tim Internal','');
/*!40000 ALTER TABLE `cyb_pelatihan` ENABLE KEYS */;

--
-- Table structure for table `cyb_pelatihan_info`
--

DROP TABLE IF EXISTS `cyb_pelatihan_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_pelatihan_info` (
  `ilt_id` smallint(2) NOT NULL AUTO_INCREMENT,
  `ilt_nama` varchar(9) NOT NULL,
  `ilt_title` varchar(46) NOT NULL,
  `ilt_simbol` varchar(9) NOT NULL,
  PRIMARY KEY (`ilt_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_pelatihan_info`
--

/*!40000 ALTER TABLE `cyb_pelatihan_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `cyb_pelatihan_info` ENABLE KEYS */;

--
-- Table structure for table `cyb_pelatihan_jenis`
--

DROP TABLE IF EXISTS `cyb_pelatihan_jenis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_pelatihan_jenis` (
  `jns_id` int(11) NOT NULL AUTO_INCREMENT,
  `jns_nama` varchar(12) NOT NULL,
  `jns_simbol` varchar(12) NOT NULL,
  PRIMARY KEY (`jns_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_pelatihan_jenis`
--

/*!40000 ALTER TABLE `cyb_pelatihan_jenis` DISABLE KEYS */;
INSERT INTO `cyb_pelatihan_jenis` VALUES (1,'Public','primary'),(2,'Inhouse','default');
/*!40000 ALTER TABLE `cyb_pelatihan_jenis` ENABLE KEYS */;

--
-- Table structure for table `cyb_pelatihan_materi`
--

DROP TABLE IF EXISTS `cyb_pelatihan_materi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_pelatihan_materi` (
  `mtr_id` int(11) NOT NULL AUTO_INCREMENT,
  `mtr_nama` varchar(64) NOT NULL,
  `mtr_jenis` varchar(9) NOT NULL,
  `mtr_waktu` datetime NOT NULL,
  `mtr_selesai` time NOT NULL,
  `mtr_pel_id` int(11) NOT NULL,
  PRIMARY KEY (`mtr_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_pelatihan_materi`
--

/*!40000 ALTER TABLE `cyb_pelatihan_materi` DISABLE KEYS */;
INSERT INTO `cyb_pelatihan_materi` VALUES (1,'Millist','soft','2015-08-15 07:00:00','11:15:00',1),(2,'Mencari tempat berlindung','hard','2015-08-20 07:08:04','11:08:08',3),(3,'Mengenali resiko kerja','hard','2015-08-20 13:08:41','15:08:48',3);
/*!40000 ALTER TABLE `cyb_pelatihan_materi` ENABLE KEYS */;

--
-- Table structure for table `cyb_pelatihan_peserta`
--

DROP TABLE IF EXISTS `cyb_pelatihan_peserta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_pelatihan_peserta` (
  `plt_id` int(11) NOT NULL AUTO_INCREMENT,
  `plt_pel_id` int(11) NOT NULL,
  `plt_usr_id` int(11) NOT NULL,
  PRIMARY KEY (`plt_id`),
  KEY `plt_pel_id` (`plt_pel_id`,`plt_usr_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_pelatihan_peserta`
--

/*!40000 ALTER TABLE `cyb_pelatihan_peserta` DISABLE KEYS */;
INSERT INTO `cyb_pelatihan_peserta` VALUES (3,1,13),(1,1,24),(6,1,25),(4,2,24),(7,3,12),(8,3,13),(5,3,25);
/*!40000 ALTER TABLE `cyb_pelatihan_peserta` ENABLE KEYS */;

--
-- Table structure for table `cyb_ruang`
--

DROP TABLE IF EXISTS `cyb_ruang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_ruang` (
  `ru_id` int(5) NOT NULL AUTO_INCREMENT,
  `ru_nama` varchar(5) NOT NULL,
  `ru_desc` varchar(54) DEFAULT NULL,
  PRIMARY KEY (`ru_id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_ruang`
--

/*!40000 ALTER TABLE `cyb_ruang` DISABLE KEYS */;
INSERT INTO `cyb_ruang` VALUES (1,'NULL','Tidak ada keterangan ruang'),(2,'R1',NULL),(3,'R2',NULL),(4,'R3',NULL),(5,'R4',NULL),(6,'R5',NULL),(7,'R6',NULL),(8,'R7',NULL),(9,'R8',NULL),(10,'R9',NULL),(11,'R10',NULL),(12,'R11',NULL),(13,'R12',NULL),(14,'R13',NULL),(15,'R14',NULL),(16,'R15',NULL),(17,'R16',NULL),(18,'R17',NULL),(19,'R18',NULL),(20,'R19',NULL),(21,'R20',NULL),(22,'R21',NULL),(23,'R22',NULL),(24,'R23',NULL),(25,'R24',NULL),(26,'R25',NULL),(27,'R26',NULL),(28,'R27',NULL),(29,'R28',NULL),(30,'R29',NULL),(31,'R30',NULL),(32,'R31',NULL),(33,'R32',NULL),(34,'R33',NULL),(35,'R34',NULL),(36,'R35',NULL),(37,'R36',NULL),(38,'R37',NULL),(39,'R38',NULL),(40,'R39',NULL),(41,'R40',NULL);
/*!40000 ALTER TABLE `cyb_ruang` ENABLE KEYS */;

--
-- Table structure for table `cyb_sessions`
--

DROP TABLE IF EXISTS `cyb_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_sessions`
--

/*!40000 ALTER TABLE `cyb_sessions` DISABLE KEYS */;
INSERT INTO `cyb_sessions` VALUES ('9f26034bf18b38433e375673f4da3f14','120.164.46.105','Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36',1455782100,'a:3:{s:9:\"user_data\";s:0:\"\";s:11:\"sess_userid\";s:1:\"2\";s:10:\"sess_login\";s:15:\"172jmsiplkay104\";}'),('2397adad3e510bee409c417dd0507ab6','120.164.46.105','Mozilla/5.0 (Windows NT 6.3; WOW64; rv:30.0) Gecko/20100101 Firefox/30.0',1455782472,'a:3:{s:9:\"user_data\";s:0:\"\";s:11:\"sess_userid\";s:2:\"29\";s:10:\"sess_login\";s:15:\"172jmsiplkay104\";}');
/*!40000 ALTER TABLE `cyb_sessions` ENABLE KEYS */;

--
-- Table structure for table `cyb_system`
--

DROP TABLE IF EXISTS `cyb_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_system` (
  `sys_id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_name` varchar(16) NOT NULL,
  `sys_theme_name` varchar(16) NOT NULL,
  `sys_theme_path` varchar(26) NOT NULL,
  `sys_version` varchar(9) NOT NULL,
  `sys_copyright` varchar(16) NOT NULL,
  `sys_year` varchar(4) NOT NULL,
  `sys_license` varchar(9) NOT NULL,
  `sys_contact` varchar(32) NOT NULL,
  `sys_help` varchar(26) NOT NULL,
  PRIMARY KEY (`sys_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_system`
--

/*!40000 ALTER TABLE `cyb_system` DISABLE KEYS */;
INSERT INTO `cyb_system` VALUES (1,'Frameigniter','Lte','','V1.0 Beta','Cyberkay Inc','2015','free','kiki.kiswanto@cyberkay.com','http://cyberkay.com');
/*!40000 ALTER TABLE `cyb_system` ENABLE KEYS */;

--
-- Table structure for table `cyb_unit_kerja`
--

DROP TABLE IF EXISTS `cyb_unit_kerja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_unit_kerja` (
  `uk_id` int(12) NOT NULL AUTO_INCREMENT,
  `uk_kode` varchar(5) NOT NULL,
  `uk_nama` varchar(64) NOT NULL,
  `uk_desc` varchar(64) NOT NULL DEFAULT '-',
  `uk_departemen` varchar(9) DEFAULT NULL,
  `uk_order` int(2) NOT NULL,
  PRIMARY KEY (`uk_id`),
  UNIQUE KEY `uk_kode` (`uk_kode`),
  KEY `uk_departemen` (`uk_departemen`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_unit_kerja`
--

/*!40000 ALTER TABLE `cyb_unit_kerja` DISABLE KEYS */;
INSERT INTO `cyb_unit_kerja` VALUES (1,'NULL','Not Set','tidak memiliki keterangan unit kerja','0',0),(15,'SEF','Seksi Electric Facility','','DTCM',2),(21,'DTCM','Departemen Toll Collection Management','','0',1),(25,'STCC','Seksi Toll Collection Control','','DTCM',3),(26,'GTB','Gerbang Tol Baros','','DTCM',4),(27,'GTBB','Gerbang Tol Buah Batu','','DTCM',5),(28,'GTP','Gerbang Tol Padalarang','','DTCM',6),(32,'GTCL','Gerbang Tol Cileunyi','','DTCM',7),(33,'GTS','Gerbang Tol Sadang','','DTCM',8),(34,'GTJ','Gerbang Tol Jatiluhur','','DTCM',9),(35,'GTK','Gerbang Tol Kopo','','DTCM',10),(36,'GTMT','Gerbang Tol Moh. Toha','','DTCM',11),(37,'GTPS','Gerbang Tol Pasteur','','DTCM',12),(38,'GTPK','Gerbang Tol Pasir Koja','','DTCM',11),(39,'DTM','Departemen Traffic Management','','0',1),(40,'STC','Seksi Traffic Control','','DTM',2),(41,'SS','Seksi Security','','DTM',3),(42,'STS','Seksi Traffic Services','','DTM',4);
/*!40000 ALTER TABLE `cyb_unit_kerja` ENABLE KEYS */;

--
-- Table structure for table `cyb_users`
--

DROP TABLE IF EXISTS `cyb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cyb_users` (
  `usr_id` int(11) NOT NULL AUTO_INCREMENT,
  `usr_username` varchar(12) NOT NULL COMMENT 'diisi dengan npp',
  `usr_password` varchar(245) NOT NULL,
  `usr_firstname` varchar(46) DEFAULT NULL,
  `usr_lastname` varchar(46) DEFAULT NULL,
  `usr_jk` varchar(1) DEFAULT NULL,
  `usr_tempat_lhr` varchar(32) DEFAULT NULL,
  `usr_tanggal_lhr` date DEFAULT NULL,
  `usr_email` varchar(64) DEFAULT NULL,
  `usr_hp` varchar(14) DEFAULT '-',
  `usr_photo` varchar(32) DEFAULT 'default.png',
  `usr_jabatan` int(5) DEFAULT '1',
  `usr_golongan` int(5) DEFAULT '1',
  `usr_ruangan` int(5) DEFAULT '1',
  `usr_baris` int(5) DEFAULT '1',
  `usr_agama` varchar(9) DEFAULT NULL,
  `usr_status` int(1) NOT NULL DEFAULT '1',
  `usr_level` int(2) NOT NULL DEFAULT '4',
  `usr_blocked` int(1) NOT NULL DEFAULT '0',
  `usr_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`usr_id`),
  UNIQUE KEY `usr_username` (`usr_username`),
  KEY `usr_level` (`usr_level`),
  KEY `usr_unit_kerja` (`usr_jabatan`),
  KEY `usr_ruangan` (`usr_ruangan`,`usr_baris`),
  KEY `usr_baris` (`usr_baris`),
  KEY `usr_golongan` (`usr_golongan`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyb_users`
--

/*!40000 ALTER TABLE `cyb_users` DISABLE KEYS */;
INSERT INTO `cyb_users` VALUES (2,'demo','fe01ce2a7fbac8fafaed7c982a04e229','user','testing','p','','0000-00-00','demo@gmail.com','-','Foto0448.jpg',1,1,1,1,'ISLAM',99,2,0,'0000-00-00 00:00:00'),(3,'05794','ae2b1fca515949e5d54fb22b8ed95575','Ricky','Distawardhana','l','-',NULL,NULL,'-','default.png',2,3,16,7,'ISLAM',1,2,0,'2015-07-11 17:00:00'),(4,'01487','ae2b1fca515949e5d54fb22b8ed95575','Yusep','Supriatna','l','-','0000-00-00','','-','default.png',4,4,1,1,'ISLAM',0,4,0,'0000-00-00 00:00:00'),(11,'10389','10389','Nurullah','','l','','0000-00-00','','-','default.png',1,5,4,2,'ISLAM',1,4,0,'2015-07-13 08:19:36'),(12,'06355','06355','Ade','Rukmana','l','','0000-00-00','','-','default.png',1,7,23,14,'ISLAM',1,4,0,'2015-07-13 08:21:49'),(13,'06359','06359','Dadang','Rohmana','l','','0000-00-00','','-','default.png',7,7,24,14,'ISLAM',1,4,0,'2015-07-13 08:24:22'),(14,'06619','f96cf3defd87bef5c6d6f1525ae0f9a9','Karman','','l','','0000-00-00','','-','default.png',8,7,20,10,'ISLAM',1,4,0,'2015-07-14 01:57:49'),(24,'05598','20ebc3b81970d6207215ed451a8c1c06','Asep','Komarwan','l','','0000-00-00','','-','default.png',1,1,1,1,'ISLAM',1,4,0,'2015-08-12 02:48:26'),(26,'12345','3e10f0d4e5f01463e8880b55da804278','Lela','nurlaela sari','p','','0000-00-00','','','IMG00232-20130618-1050.jpg',1,1,1,1,'ISLAM',1,1,0,'2016-02-16 14:43:14'),(29,'06536','6e19c395ebc4c58f266b4faefd6bf757','Teguh','Hartono','l','','0000-00-00','','','default.png',1,1,1,1,'ISLAM',1,2,0,'2016-02-18 07:35:35');
/*!40000 ALTER TABLE `cyb_users` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-02-18  8:22:31
